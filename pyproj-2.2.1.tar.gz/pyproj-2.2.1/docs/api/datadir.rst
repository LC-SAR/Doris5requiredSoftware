Data Directory
==============

pyproj.datadir.get_data_dir
---------------------------

.. autofunction:: pyproj.datadir.get_data_dir


pyproj.datadir.set_data_dir
---------------------------

.. autofunction:: pyproj.datadir.set_data_dir


pyproj.datadir.append_data_dir
------------------------------

.. autofunction:: pyproj.datadir.append_data_dir
