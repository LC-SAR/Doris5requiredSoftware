Show Versions
=============

pyproj.show_versions
--------------------

.. autofunction:: pyproj.show_versions
